//David Wilcken
//SDI
//August 2015
//Output Assignment

//String variable
alert ("What city do I currently Live ?in");
var currentCity = "Key West Florida";
console.log (currentCity);

//Number variable
alert ("How many years have I been in the Air Force?");
var numberOfYearsInTheAirForce = 7;
console.log (numberOfYearsInTheAirForce);

//Boolean variable
alert ("Do I like Mexican food?");
var mexicanFoodIsMyFavorite = true;
console.log (mexicanFoodIsMyFavorite);

//Just for fun Arrays
alert ("One of my favorite hobbies");
var oneOfmyFavoriteHobbies = ["Bagpipes","Shooting","Woodworking","JavaScript"];
console.log(oneOfmyFavoriteHobbies[0]);